KIKYO POKE V2 — Android project foundation
Theme: Black + Purple + Gold

This is a fresh Android Studio project foundation with:
- A polished Pokémon-trainer themed app shell.
- Home, trainer, Pokémon, and connection screens.
- A live network-latency indicator (requires a reachable HTTPS API).
- A configurable API base URL.
- A music folder for your own legally usable audio files.
- GitHub Actions workflow to build a debug APK.

IMPORTANT:
This is the app foundation, not a completed Pokémon game backend or finished battle/catching system.
The current KelvinHost address (http://137.66.52.81:3019) previously returned ERR_CONNECTION_RESET, so it is NOT preconfigured as a working endpoint. Set API_BASE_URL in app/src/main/assets/config.js only after your host provides a reachable HTTPS API.
WhatsApp account linking must use an authorised WhatsApp-supported linking/approval flow. This project does not bypass verification or silently log in using only a phone number.

Build:
1. Upload the contents of this ZIP to a new GitHub repository.
2. GitHub -> Actions -> Android Debug APK -> Run workflow.
3. Download the APK from the workflow run's Artifacts section.
4. For local build, open the project in Android Studio and build the app.

Do not upload API secrets into the APK or GitHub repository.
