// Set this only to a publicly reachable HTTPS API base URL.
// Example: https://api.yourdomain.com
// Do not put API_SECRET, passwords, or private server keys in this file.
window.KIKYO_CONFIG = {
  API_BASE_URL: "",
  HEALTH_PATH: "/health"
};
