# KIKYO POKE V1 ONLINE — starter project

Package ID: `com.kikyo.pokev1`  
Firebase project: `kikyo-poke-v1`

## Included in this starter
- Android Java project and GitHub Actions APK workflow.
- Firebase Authentication email/password registration and login.
- Firestore player profile creation and read.
- A small local PvE battle prototype with five stages.

## Not implemented yet
Real-time PvP matchmaking/battle authority, raids, tournament brackets, friends,
leaderboards, Pokémon collection/Pokédex, full moves/evolution, and secure
server-side reward validation are not implemented in this starter. They require
additional game logic and Firestore security rules; this ZIP must not be
described as the finished online game.

## Firebase setup required
1. In Firebase Console, enable Authentication > Email/Password.
2. Create a Cloud Firestore database.
3. Replace test rules with authenticated, owner-scoped rules before real players use it.
4. Ensure the Android app registered in Firebase has package name `com.kikyo.pokev1`.

Do not add Firebase Admin service-account credentials to this Android project.
The `google-services.json` file is the Android client configuration.
