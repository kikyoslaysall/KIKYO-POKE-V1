package com.kikyo.pokev1;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private LinearLayout root;
    private EditText email, password, trainerName;
    private TextView status;
    private int stage = 1, playerHp = 100, enemyHp = 80;
    private final String[] enemies = {"Rattata", "Pidgeotto", "Onix", "Gengar", "Dragonite"};
    private final Random random = new Random();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        showHome();
    }

    private void shell(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(Color.rgb(9,6,16));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.rgb(221,185,92));
        heading.setTextSize(27);
        heading.setGravity(Gravity.CENTER);
        heading.setPadding(0, 8, 0, 22);
        root.addView(heading);
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(Color.WHITE); t.setTextSize(16);
        t.setPadding(0, 10, 0, 10); root.addView(t); return t;
    }

    private EditText input(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setSingleLine(true);
        e.setTextColor(Color.WHITE); e.setHintTextColor(Color.LTGRAY);
        if (secret) e.setInputType(129);
        root.addView(e); return e;
    }

    private void button(String text, Runnable action) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(91,39,139)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8); root.addView(b,p);
        b.setOnClickListener(v -> action.run());
    }

    private void message(String s) {
        if (status != null) status.setText(s);
        else Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void showHome() {
        shell("KIKYO POKE");
        label("ONLINE EDITION  •  BLACK / PURPLE / GOLD");
        if (auth.getCurrentUser() != null) { showDashboard(); return; }
        label("Create an account or sign in to save your trainer profile online.");
        email = input("Email address", false);
        password = input("Password (6+ characters)", true);
        trainerName = input("Trainer name (for registration)", false);
        status = label("");
        button("REGISTER", this::register);
        button("LOGIN", this::login);
    }

    private void register() {
        String e=email.getText().toString().trim(), p=password.getText().toString();
        String n=trainerName.getText().toString().trim();
        if(e.isEmpty() || p.length()<6 || n.isEmpty()) { message("Enter email, trainer name and a password of at least 6 characters."); return; }
        auth.createUserWithEmailAndPassword(e,p).addOnSuccessListener(r -> {
            String uid=auth.getCurrentUser().getUid();
            Map<String,Object> profile=new HashMap<>();
            profile.put("uid",uid); profile.put("email",e); profile.put("trainerName",n);
            profile.put("coins",500); profile.put("xp",0); profile.put("createdAt",new Date());
            db.collection("players").document(uid).set(profile)
              .addOnSuccessListener(x -> showDashboard())
              .addOnFailureListener(err -> message("Account created, but profile save failed: "+err.getMessage()));
        }).addOnFailureListener(err -> message("Registration failed: "+err.getMessage()));
    }

    private void login() {
        String e=email.getText().toString().trim(), p=password.getText().toString();
        auth.signInWithEmailAndPassword(e,p).addOnSuccessListener(r -> showDashboard())
          .addOnFailureListener(err -> message("Login failed: "+err.getMessage()));
    }

    private void showDashboard() {
        status=null;
        shell("KIKYO POKE");
        label("Your trainer account is connected to Firebase.");
        String uid=auth.getCurrentUser().getUid();
        db.collection("players").document(uid).get().addOnSuccessListener(doc -> {
            if(doc.exists()) label("Trainer: "+doc.getString("trainerName")+
                "\nCoins: "+doc.getLong("coins")+"\nXP: "+doc.getLong("xp"));
        });
        button("PvE STORY BATTLE", this::startPve);
        button("ONLINE PvP (coming next)", () -> notice("PvP matchmaking and trusted battle resolution still need to be implemented."));
        button("RAIDS (coming next)", () -> notice("Raid lobbies, boss turns and reward validation are planned for the next build stage."));
        button("TOURNAMENTS (coming next)", () -> notice("Tournament registration, brackets and match scheduling are planned for the next build stage."));
        button("LEADERBOARD (coming next)", () -> notice("Leaderboard queries and anti-cheat reward handling are not enabled yet."));
        button("SIGN OUT", () -> { auth.signOut(); showHome(); });
    }

    private void notice(String s) { new android.app.AlertDialog.Builder(this).setTitle("KIKYO POKE").setMessage(s).setPositiveButton("OK",null).show(); }

    private void startPve() {
        stage=1; playerHp=100; enemyHp=80; showBattle();
    }

    private void showBattle() {
        shell("PvE • STAGE "+stage);
        String enemy=enemies[Math.min(stage-1,enemies.length-1)];
        label("Your Pokémon  HP: "+playerHp+"/100\nEnemy "+enemy+"  HP: "+enemyHp+"/80");
        label("Choose your turn. This is a local PvE prototype; cloud-saved rewards and full Pokémon roster are a later integration step.");
        button("QUICK ATTACK", () -> attack(12, enemy));
        button("POWER MOVE", () -> attack(20, enemy));
        button("HEAL", () -> { playerHp=Math.min(100,playerHp+18); enemyTurn(enemy); });
        button("FORFEIT", this::showDashboard);
    }

    private void attack(int damage, String enemy) {
        enemyHp=Math.max(0,enemyHp-damage);
        if(enemyHp==0) {
            if(stage>=5) { notice("You cleared the current PvE prototype stages!"); showDashboard(); }
            else { stage++; playerHp=Math.min(100,playerHp+20); enemyHp=80; showBattle(); }
        } else enemyTurn(enemy);
    }

    private void enemyTurn(String enemy) {
        playerHp=Math.max(0,playerHp-(8+random.nextInt(10)));
        if(playerHp==0) { notice("Your Pokémon needs recovery. Try the stage again."); startPve(); }
        else showBattle();
    }
}
